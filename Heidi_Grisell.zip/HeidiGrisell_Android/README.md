# Heidi Grisell — aplicación Android local

Proyecto fuente Android Studio (Kotlin + Jetpack Compose). Nombre visible y `applicationId`: `Heidi Grisell` / `com.heidigrisell.app`.

## Funciones incluidas
- Inicio con resumen de ingresos, gastos y balance.
- Registro de ingresos y gastos.
- Ventas y compras por producto; actualizan el inventario automáticamente.
- Inventario con SKU, stock, costo y precio de venta.
- Alertas visuales de stock bajo (3 unidades o menos).
- Registro de clientes y proveedores.
- Reporte financiero básico y valorización del inventario al costo.
- Copia de seguridad y restauración de productos, contactos y movimientos en JSON.
- Moneda: soles peruanos (S/).
- Almacenamiento local en el dispositivo. No usa Firebase, Internet, correo, Gmail, Facebook ni inicio de sesión.

## Compilar
1. Descomprime el ZIP.
2. Abre la carpeta en Android Studio.
3. Espera la sincronización de Gradle.
4. Ejecuta en un emulador o celular Android.

## Alcance y advertencias
Este archivo es el código fuente del proyecto, no un APK compilado ni probado en un dispositivo. Es una primera versión funcional de los módulos descritos. No incluye todavía facturación electrónica SUNAT, impresión, lector de códigos, cuentas por cobrar/pagar, edición/eliminación de productos o contactos, ni reportes filtrados por fechas.
Los datos se guardan localmente. Haz copias de seguridad con frecuencia; al desinstalar o borrar los datos de la app podrías perder la información.
