package com.heidigrisell.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Forest = Color(0xFF176B45)
private val Pale = Color(0xFFEAF5EE)
private val Background = Color(0xFFF5F8F6)
private val Ink = Color(0xFF183329)

data class Product(val id:String=UUID.randomUUID().toString(), val name:String, val sku:String,
                   val stock:Double, val cost:Double, val price:Double)
data class Contact(val id:String=UUID.randomUUID().toString(), val name:String,
                   val phone:String, val kind:String)
data class Movement(val id:String=UUID.randomUUID().toString(), val title:String, val amount:Double,
                    val type:String, val category:String, val date:Long=System.currentTimeMillis(),
                    val productId:String="", val quantity:Double=0.0)

class LocalStore(context:Context) {
    private val prefs=context.getSharedPreferences("heidi_grisell_local", Context.MODE_PRIVATE)
    fun loadProducts():List<Product> = runCatching {
        val a=JSONArray(prefs.getString("products","[]"))
        (0 until a.length()).map { i -> val o=a.getJSONObject(i)
            Product(o.getString("id"),o.getString("name"),o.optString("sku"),
                o.optDouble("stock"),o.optDouble("cost"),o.optDouble("price")) }
    }.getOrDefault(emptyList())
    fun loadContacts():List<Contact> = runCatching {
        val a=JSONArray(prefs.getString("contacts","[]"))
        (0 until a.length()).map { i -> val o=a.getJSONObject(i)
            Contact(o.getString("id"),o.getString("name"),o.optString("phone"),o.getString("kind")) }
    }.getOrDefault(emptyList())
    fun loadMovements():List<Movement> = runCatching {
        val a=JSONArray(prefs.getString("movements","[]"))
        (0 until a.length()).map { i -> val o=a.getJSONObject(i)
            Movement(o.getString("id"),o.getString("title"),o.getDouble("amount"),o.getString("type"),
                o.optString("category"),o.optLong("date"),o.optString("productId"),o.optDouble("quantity")) }
    }.getOrDefault(emptyList()).sortedByDescending { it.date }
    fun save(p:List<Product>, c:List<Contact>, m:List<Movement>) {
        val pa=JSONArray(); p.forEach { pa.put(JSONObject().put("id",it.id).put("name",it.name)
            .put("sku",it.sku).put("stock",it.stock).put("cost",it.cost).put("price",it.price)) }
        val ca=JSONArray(); c.forEach { ca.put(JSONObject().put("id",it.id).put("name",it.name)
            .put("phone",it.phone).put("kind",it.kind)) }
        val ma=JSONArray(); m.forEach { ma.put(JSONObject().put("id",it.id).put("title",it.title)
            .put("amount",it.amount).put("type",it.type).put("category",it.category)
            .put("date",it.date).put("productId",it.productId).put("quantity",it.quantity)) }
        prefs.edit().putString("products",pa.toString()).putString("contacts",ca.toString())
            .putString("movements",ma.toString()).apply()
    }
    fun exportAll():String {
        val p=JSONArray(); loadProducts().forEach { p.put(JSONObject().put("id",it.id).put("name",it.name)
            .put("sku",it.sku).put("stock",it.stock).put("cost",it.cost).put("price",it.price)) }
        val c=JSONArray(); loadContacts().forEach { c.put(JSONObject().put("id",it.id).put("name",it.name)
            .put("phone",it.phone).put("kind",it.kind)) }
        val m=JSONArray(); loadMovements().forEach { m.put(JSONObject().put("id",it.id).put("title",it.title)
            .put("amount",it.amount).put("type",it.type).put("category",it.category).put("date",it.date)
            .put("productId",it.productId).put("quantity",it.quantity)) }
        return JSONObject().put("app","Heidi Grisell").put("version",1)
            .put("products",p).put("contacts",c).put("movements",m).toString(2)
    }
    fun importAll(raw:String):Triple<List<Product>,List<Contact>,List<Movement>> {
        val o=JSONObject(raw)
        val p=o.getJSONArray("products"); val c=o.getJSONArray("contacts"); val m=o.getJSONArray("movements")
        val ps=(0 until p.length()).map { i -> val x=p.getJSONObject(i)
            Product(x.getString("id"),x.getString("name"),x.optString("sku"),x.optDouble("stock"),
                x.optDouble("cost"),x.optDouble("price")) }
        val cs=(0 until c.length()).map { i -> val x=c.getJSONObject(i)
            Contact(x.getString("id"),x.getString("name"),x.optString("phone"),x.getString("kind")) }
        val ms=(0 until m.length()).map { i -> val x=m.getJSONObject(i)
            Movement(x.getString("id"),x.getString("title"),x.getDouble("amount"),x.getString("type"),
                x.optString("category"),x.optLong("date"),x.optString("productId"),x.optDouble("quantity")) }
        return Triple(ps,cs,ms)
    }
}

class MainActivity:ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState)
        setContent { HeidiApp() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun HeidiApp() {
    val ctx=androidx.compose.ui.platform.LocalContext.current
    val store=remember { LocalStore(ctx) }
    var products by remember { mutableStateOf(store.loadProducts()) }
    var contacts by remember { mutableStateOf(store.loadContacts()) }
    var moves by remember { mutableStateOf(store.loadMovements()) }
    var tab by remember { mutableStateOf("Inicio") }
    var dialog by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    fun persist()=store.save(products,contacts,moves)
    val income=moves.filter { it.type=="Ingreso" || it.type=="Venta" }.sumOf { it.amount }
    val expense=moves.filter { it.type=="Gasto" || it.type=="Compra" }.sumOf { it.amount }
    val fmt:(Double)->String={ "S/ "+NumberFormat.getNumberInstance(Locale("es","PE")).format(it) }
    val backup=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri:Uri? ->
        if(uri!=null) runCatching { ctx.contentResolver.openOutputStream(uri)?.use { it.write(store.exportAll().toByteArray()) }
            notice="Copia de seguridad creada" }.onFailure { notice="No se pudo crear la copia" } }
    val restore=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri:Uri? ->
        if(uri!=null) runCatching { val raw=ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            val all=store.importAll(raw); products=all.first; contacts=all.second; moves=all.third; persist()
            notice="Datos restaurados correctamente" }.onFailure { notice="No se pudo restaurar: archivo inválido" } }

    MaterialTheme(colorScheme=lightColorScheme(primary=Forest,secondary=Color(0xFF4B956D),background=Background,surface=Color.White)) {
        Scaffold(topBar={ TopAppBar(title={ Column {
            Text("Heidi Grisell",fontWeight=FontWeight.Bold)
            Text("Administración de tu negocio",style=MaterialTheme.typography.labelSmall,color=Color.Gray)
        } },actions={
            IconButton(onClick={backup.launch("HeidiGrisell-respaldo.json")}) { Icon(Icons.Default.SaveAlt,"Crear copia") }
            IconButton(onClick={restore.launch(arrayOf("application/json","text/*"))}) { Icon(Icons.Default.Restore,"Restaurar") }
        }) }, floatingActionButton={
            if(tab=="Inventario" || tab=="Contactos" || tab=="Movimientos") FloatingActionButton(onClick={
                dialog=when(tab){"Inventario"->"producto";"Contactos"->"contacto";else->"movimiento"}
            },containerColor=Forest,contentColor=Color.White) { Icon(Icons.Default.Add,"Agregar") }
        }, bottomBar={
            NavigationBar {
                val tabs=listOf("Inicio","Ventas","Compras","Inventario","Contactos","Reportes")
                tabs.forEach { t -> NavigationBarItem(selected=tab==t,onClick={tab=t},
                    icon={ Icon(when(t) {
                        "Inicio"->Icons.Default.Home; "Ventas"->Icons.Default.PointOfSale
                        "Compras"->Icons.Default.ShoppingCart; "Inventario"->Icons.Default.Inventory2
                        "Contactos"->Icons.Default.People; else->Icons.Default.BarChart
                    },contentDescription=t) },label={Text(t, maxLines=1, style=MaterialTheme.typography.labelSmall)}) }
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().background(Background).padding(pad).padding(14.dp)) {
                when(tab) {
                    "Inicio" -> {
                        Text("Resumen del negocio",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Ink)
                        Spacer(Modifier.height(10.dp))
                        Card(colors=CardDefaults.cardColors(containerColor=Forest),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Text("Balance registrado",color=Color.White.copy(alpha=.8f))
                                Text(fmt(income-expense),color=Color.White,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
                                Text("Ingresos y ventas menos gastos y compras",color=Color.White.copy(alpha=.8f),style=MaterialTheme.typography.bodySmall)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            Stat("Ingresos / ventas",fmt(income),Pale,Modifier.weight(1f))
                            Stat("Gastos / compras",fmt(expense),Color(0xFFFFECE8),Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            Stat("Productos",products.size.toString(),Color.White,Modifier.weight(1f))
                            Stat("Contactos",contacts.size.toString(),Color.White,Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("Últimos movimientos",fontWeight=FontWeight.Bold)
                        MoveList(moves.take(5),fmt)
                    }
                    "Ventas" -> {
                        SectionHeader("Ventas","Registra ventas y descuenta automáticamente el stock.")
                        Button(onClick={dialog="venta"},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Registrar venta") }
                        MoveList(moves.filter{it.type=="Venta"},fmt)
                    }
                    "Compras" -> {
                        SectionHeader("Compras","Registra compras y aumenta automáticamente el stock.")
                        Button(onClick={dialog="compra"},modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Add,null); Spacer(Modifier.width(6.dp)); Text("Registrar compra") }
                        MoveList(moves.filter{it.type=="Compra"},fmt)
                    }
                    "Inventario" -> {
                        SectionHeader("Inventario","Productos, códigos, costos, precios y existencias.")
                        if(products.isEmpty()) Empty("Aún no hay productos. Pulsa + para agregar.")
                        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                            items(products,key={it.id}) { p -> Card {
                                Row(Modifier.fillMaxWidth().padding(13.dp),verticalAlignment=Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(p.name,fontWeight=FontWeight.SemiBold)
                                        Text("Código: ${p.sku.ifBlank{"—"}}  •  Stock: ${p.stock}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                                        Text("Costo ${fmt(p.cost)}  •  Venta ${fmt(p.price)}",style=MaterialTheme.typography.bodySmall)
                                    }
                                    if(p.stock<=3) Text("Stock bajo",color=Color(0xFFB45B32),style=MaterialTheme.typography.labelSmall)
                                }
                            } }
                        }
                    }
                    "Contactos" -> {
                        SectionHeader("Clientes y proveedores","Guarda datos de contacto de tu negocio.")
                        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                            items(contacts,key={it.id}) { c -> Card {
                                Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically) {
                                    Icon(if(c.kind=="Cliente") Icons.Default.Person else Icons.Default.LocalShipping,null,tint=Forest)
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text(c.name,fontWeight=FontWeight.SemiBold)
                                        Text("${c.kind} • ${c.phone.ifBlank{"Sin teléfono"}}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                                    }
                                }
                            } }
                        }
                        if(contacts.isEmpty()) Empty("Agrega clientes o proveedores con el botón +.")
                    }
                    "Reportes" -> {
                        SectionHeader("Reportes financieros","Totales calculados con la información guardada.")
                        Stat("Ingresos y ventas",fmt(income),Pale,Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        Stat("Gastos y compras",fmt(expense),Color(0xFFFFECE8),Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        Stat("Resultado neto",fmt(income-expense),if(income>=expense) Pale else Color(0xFFFFECE8),Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        Stat("Valor del inventario (a costo)",fmt(products.sumOf{it.stock*it.cost}),Color.White,Modifier.fillMaxWidth())
                        Spacer(Modifier.height(12.dp))
                        Text("Movimientos registrados: ${moves.size}")
                        Text("Productos en catálogo: ${products.size}")
                        Text("Clientes y proveedores: ${contacts.size}")
                        Spacer(Modifier.height(12.dp))
                        Text("Consejo: crea una copia de seguridad periódicamente desde el icono de guardar.",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    when(dialog) {
        "producto" -> ProductDialog({dialog=""}) { p -> products=products+p; persist(); dialog="" }
        "contacto" -> ContactDialog({dialog=""}) { c -> contacts=contacts+c; persist(); dialog="" }
        "movimiento" -> BasicMoveDialog({dialog=""}) { title,amount,type,cat ->
            moves=listOf(Movement(title=title,amount=amount,type=type,category=cat))+moves; persist(); dialog=""
        }
        "venta","compra" -> TradeDialog(dialog,products,contacts,{dialog=""}) { product,qty,unit,contact ->
            val isSale=dialog=="venta"
            val total=qty*unit
            products=products.map { if(it.id==product.id) it.copy(stock=it.stock+(if(isSale)-qty else qty)) else it }
            moves=listOf(Movement(title="${if(isSale)"Venta" else "Compra"}: ${product.name}${if(contact.isNotBlank())" • $contact" else ""}",
                amount=total,type=if(isSale)"Venta" else "Compra",category=if(isSale)"Ventas" else "Compras",
                productId=product.id,quantity=qty))+moves
            persist(); dialog=""
        }
    }
    if(notice.isNotBlank()) AlertDialog(onDismissRequest={notice=""},confirmButton={TextButton(onClick={notice=""}){Text("Aceptar")}},
        title={Text("Heidi Grisell")},text={Text(notice)})
}

@Composable fun SectionHeader(title:String,subtitle:String) {
    Text(title,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,color=Ink)
    Text(subtitle,color=Color.Gray,style=MaterialTheme.typography.bodySmall)
    Spacer(Modifier.height(10.dp))
}
@Composable fun Stat(title:String,value:String,color:Color,modifier:Modifier=Modifier) {
    Card(modifier,colors=CardDefaults.cardColors(containerColor=color),shape=RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) { Text(title,style=MaterialTheme.typography.bodySmall,color=Color.DarkGray); Spacer(Modifier.height(5.dp)); Text(value,fontWeight=FontWeight.Bold,color=Ink) }
    }
}
@Composable fun Empty(text:String) { Box(Modifier.fillMaxWidth().padding(24.dp),contentAlignment=Alignment.Center){Text(text,color=Color.Gray)} }
@Composable fun MoveList(items:List<Movement>,fmt:(Double)->String) {
    if(items.isEmpty()) { Empty("Todavía no hay registros.") }
    else LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)) {
        items(items,key={it.id}) { m -> Card {
            Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                Icon(if(m.type=="Venta"||m.type=="Ingreso")Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                    null,tint=if(m.type=="Venta"||m.type=="Ingreso")Forest else Color(0xFFC65D4B))
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(m.title,fontWeight=FontWeight.Medium)
                    Text("${m.type} • ${SimpleDateFormat("dd/MM/yyyy",Locale("es","PE")).format(Date(m.date))}",color=Color.Gray,style=MaterialTheme.typography.bodySmall)
                }
                Text(fmt(m.amount),fontWeight=FontWeight.Bold)
            }
        } }
    }
}

@Composable fun ProductDialog(close:()->Unit,save:(Product)->Unit) {
    var name by remember{mutableStateOf("")}; var sku by remember{mutableStateOf("")}
    var stock by remember{mutableStateOf("0")}; var cost by remember{mutableStateOf("")}; var price by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=close,title={Text("Nuevo producto")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
        OutlinedTextField(name,{name=it},label={Text("Nombre")},singleLine=true)
        OutlinedTextField(sku,{sku=it},label={Text("Código / SKU")},singleLine=true)
        OutlinedTextField(stock,{stock=it},label={Text("Stock inicial")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
        OutlinedTextField(cost,{cost=it},label={Text("Costo unitario (S/)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
        OutlinedTextField(price,{price=it},label={Text("Precio de venta (S/)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
    }},confirmButton={TextButton(onClick={
        val s=stock.toDoubleOrNull()?:0.0; val c=cost.replace(",",".").toDoubleOrNull(); val p=price.replace(",",".").toDoubleOrNull()
        if(name.isNotBlank()&&c!=null&&p!=null&&s>=0&&c>=0&&p>=0) save(Product(name=name.trim(),sku=sku.trim(),stock=s,cost=c,price=p))
    }){Text("Guardar")}},dismissButton={TextButton(onClick=close){Text("Cancelar")}})
}
@Composable fun ContactDialog(close:()->Unit,save:(Contact)->Unit) {
    var name by remember{mutableStateOf("")}; var phone by remember{mutableStateOf("")}; var kind by remember{mutableStateOf("Cliente")}
    AlertDialog(onDismissRequest=close,title={Text("Nuevo contacto")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(name,{name=it},label={Text("Nombre")},singleLine=true)
        OutlinedTextField(phone,{phone=it},label={Text("Teléfono")},singleLine=true)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            FilterChip(kind=="Cliente",{kind="Cliente"},label={Text("Cliente")})
            FilterChip(kind=="Proveedor",{kind="Proveedor"},label={Text("Proveedor")})
        }
    }},confirmButton={TextButton(onClick={if(name.isNotBlank())save(Contact(name=name.trim(),phone=phone.trim(),kind=kind))){Text("Guardar")}},
        dismissButton={TextButton(onClick=close){Text("Cancelar")}})
}
@Composable fun BasicMoveDialog(close:()->Unit,save:(String,Double,String,String)->Unit) {
    var title by remember{mutableStateOf("")}; var amount by remember{mutableStateOf("")}; var type by remember{mutableStateOf("Ingreso")}; var category by remember{mutableStateOf("General")}
    AlertDialog(onDismissRequest=close,title={Text("Nuevo movimiento")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(title,{title=it},label={Text("Descripción")},singleLine=true)
        OutlinedTextField(amount,{amount=it},label={Text("Monto (S/)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(type=="Ingreso",{type="Ingreso"},label={Text("Ingreso")});FilterChip(type=="Gasto",{type="Gasto"},label={Text("Gasto")})}
        OutlinedTextField(category,{category=it},label={Text("Categoría")},singleLine=true)
    }},confirmButton={TextButton(onClick={val v=amount.replace(",",".").toDoubleOrNull();if(title.isNotBlank()&&v!=null&&v>0)save(title.trim(),v,type,category)}){Text("Guardar")}},
        dismissButton={TextButton(onClick=close){Text("Cancelar")}})
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun TradeDialog(mode:String,products:List<Product>,contacts:List<Contact>,close:()->Unit,
                            save:(Product,Double,Double,String)->Unit) {
    var selected by remember{mutableStateOf(products.firstOrNull()?.id.orEmpty())}
    var qty by remember{mutableStateOf("1")}; var unit by remember{mutableStateOf("")}; var contact by remember{mutableStateOf("")}
    var expanded by remember{mutableStateOf(false)}
    val product=products.firstOrNull{it.id==selected}
    AlertDialog(onDismissRequest=close,title={Text(if(mode=="venta")"Registrar venta" else "Registrar compra")},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            if(products.isEmpty()) Text("Primero agrega productos en Inventario.")
            else {
                ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}) {
                    OutlinedTextField(value=product?.name.orEmpty(),onValueChange={},readOnly=true,label={Text("Producto")},
                        trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)},modifier=Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
                        products.forEach { p -> DropdownMenuItem(text={Text("${p.name} (stock ${p.stock})")},onClick={
                            selected=p.id; unit=if(mode=="venta")p.price.toString() else p.cost.toString(); expanded=false
                        }) }
                    }
                }
                OutlinedTextField(qty,{qty=it},label={Text("Cantidad")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
                OutlinedTextField(unit,{unit=it},label={Text("Precio / costo unitario (S/)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
                OutlinedTextField(contact,{contact=it},label={Text("Cliente / proveedor (opcional)")},singleLine=true)
                Text("Total: S/ "+((qty.toDoubleOrNull()?:0.0)*(unit.replace(",",".").toDoubleOrNull()?:0.0)),fontWeight=FontWeight.Bold)
                if(mode=="venta"&&product!=null&&(qty.toDoubleOrNull()?:0.0)>product.stock) Text("No hay stock suficiente.",color=Color.Red)
            }
        }},confirmButton={TextButton(onClick={
            val q=qty.replace(",",".").toDoubleOrNull(); val u=unit.replace(",",".").toDoubleOrNull()
            if(product!=null&&q!=null&&u!=null&&q>0&&u>0&&(mode!="venta"||q<=product.stock))save(product,q,u,contact.trim())
        },enabled=product!=null){Text("Guardar")}},dismissButton={TextButton(onClick=close){Text("Cancelar")}})
}
